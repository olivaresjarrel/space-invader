import pygame
from pygame.sprite import Sprite


class Alien(Sprite):
    def __init__(self, settings, screen):

        super().__init__()
        self.screen = screen
        self.settings = settings

        # Load the alien image and set its rect attribute.
        self.image = pygame.image.load('images/enemy1_1.png')
        self.image = pygame.transform.scale(self.image, (60, 54))

        self.image2 = pygame.image.load('images/enemy1_2.png')
        self.image2 = pygame.transform.scale(self.image2, (60, 54))

        self.rect = self.image2.get_rect()

        # Start each new alien near the top left of the screen.
        self.rect.x = self.rect.width
        self.rect.y = self.rect.height

        # Store the alien's exact horizontal position.
        self.x = float(self.rect.x)

        alien1_current = 2

    def blitme(self):
        # drawn onto the screen
        if self.alien1_current == 1:
            self.screen.blit(self.image, self.rect)
            alien1_current = 2
        else:
            self.screen.blit(self.image2, self.rect)
            alien1_current = 1

    def update(self):
        # move alien to the left or right
        self.x += (self.settings.alien_speed_factor *
                   self.settings.fleet_direction)
        self.rect.x = self.x

    def check_edges(self):
        # returns true if aliens is at edge
        screen_rect = self.screen.get_rect()
        if self.rect.right >= screen_rect.right:
            return True
        if self.rect.left <= 0:
            return True
