import sys
import pygame

from pygame.sprite import Group
from ship import Ship
from alien import Alien
from scoreboard import Scoreboard
from button import Button
from settings import Settings
from game_stats import GameStats
from bunker import Bunker
import game_functions as gf


def run_game():
    # initialize game and create a screen object
    pygame.init()

    settings = Settings()
    screen = pygame.display.set_mode(settings.dim())
    pygame.display.set_caption("Alien Invasion")

    stats = GameStats(settings)
    sb = Scoreboard(settings, screen, stats)
    play_button = Button(settings, screen, "Play")
    # make a ship, group of bullets, group of aliens
    ship = Ship(settings, screen)
    bullets = Group()
    aliens = Group()
    bunker = Group()

    # alien = Alien(settings, screen)
    # number_of_aliens = 36

    gf.create_fleet(settings, stats, screen, ship, aliens, bullets)

    FPS = 120


    # main game loop
    while True:

        # Watch for keyboard and mouse event
        gf.check_events(settings, screen, stats, sb, bunker, play_button, ship, aliens, bullets)
        if stats.game_active:
            ship.update()
            gf.update_bullets(settings, stats, screen, sb, ship, aliens, bullets)
            gf.update_aliens(settings, stats, screen, sb, ship, aliens, bullets)
        print(len(bullets))

        # update screen
        gf.update_screen(settings, stats, screen, sb, ship, aliens, bullets, play_button)

        FPSClock = pygame.time.Clock()

        FPSClock.tick(FPS)


run_game()
