from pygame.sprite import Sprite


class Bunker(Sprite):
    def __init__(self, size, color, row, column):
        super(Bunker, self).__init__()
        self.height = size
        self.width = size
        self.color = color
        # self.image = Surface((self.width, self.height))
        self.image.fill(self.color)
        self.rect = self.image.get_rect()
        self.row = row
        self.column = column

    def make_bunkers(self, number):
        for row in range(4):
            for column in range(9):
                bunker = Bunker(10, '#228B22', row, column)
                bunker.rect.x = 50 + (200 * number) + (column * bunker.width)
                bunker.rect.y = 400 + (row * bunker.height)

