import pygame.font

class Button:
    def __init__(self, settings, screen, msg):
        # intialize
        self.screen = screen
        self.screen_rect = screen.get_rect()

        # dimensions of button
        self.play_width, self.play_height = 200, 50
        self.score_width, self.score_height = 1000, 600
        self.button_color = pygame.Color("#000000")
        self.text1_color = pygame.Color("#FFFFFF")
        self.text2_color = pygame.Color("#00FF00")
        self.font = pygame.font.SysFont(None, 48)

        # build the button's rect
        self.rect = pygame.Rect(0, 0, self.play_width, self.play_height)
        self.rect.center = self.screen_rect.center

        self.score_rect = pygame.Rect(0, 0, self.score_width, self.score_height)
        self.score_rect.center = self.screen_rect.center

        self.prep_msg(msg)

    def prep_msg(self, msg):
        # turn message into an image
        self.msg_image = self.font.render(msg, True, self.text1_color,
                                          self.button_color)
        self.msg_image_rect = self.msg_image.get_rect()
        self.msg_image_rect.center = self.rect.center

    def draw_play_button(self):
        self.screen.fill(self.button_color, self.rect)
        self.screen.blit(self.msg_image, self.msg_image_rect)

    # def prep_score(self, msg):
    #     self.score_img = self.font.render('Space', True, self.text1_color,
    #                                       self.button_color)
    #     self.score_img_rect = self.score_img.get_rect()
    #
    # def draw_score_display(self):
    #     self.screen.fill(self.button_color, self.rect)
    #     self.screen.blit(self.score_img, self.score_img_rect)